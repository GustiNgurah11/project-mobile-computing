<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: *");
header("Access-Control-Allow-Methods: *");
header("Content-Type: application/json");

include "koneksi.php";

$email = $_GET['email'] ?? '';

if ($email != '') {
    // Statistik milik user tertentu
    $totalQuery = mysqli_query($conn,
        "SELECT COUNT(*) as total FROM laporann WHERE email='$email'"
    );
    $selesaiQuery = mysqli_query($conn,
        "SELECT COUNT(*) as total FROM laporann WHERE email='$email' AND status='Selesai'"
    );
} else {
    // Statistik keseluruhan (untuk admin)
    $totalQuery = mysqli_query($conn, "SELECT COUNT(*) as total FROM laporann");
    $selesaiQuery = mysqli_query($conn, "SELECT COUNT(*) as total FROM laporann WHERE status='Selesai'");
}

$total = mysqli_fetch_assoc($totalQuery);
$selesai = mysqli_fetch_assoc($selesaiQuery);

echo json_encode([
    "total_laporan" => $total['total'],
    "laporan_selesai" => $selesai['total']
]);
?>