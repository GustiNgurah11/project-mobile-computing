<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: *");
header("Access-Control-Allow-Methods: *");
header("Content-Type: application/json");

include "koneksi.php";

$email = $_GET['email'] ?? '';

if ($email != '') {
    // Kalau ada email → tampil laporan milik user itu saja
    $query = mysqli_query($conn,
        "SELECT * FROM laporann WHERE email='$email' ORDER BY id ASC"
    );
} else {
    // Kalau tidak ada email → tampil semua (untuk admin)
    $query = mysqli_query($conn,
        "SELECT * FROM laporann ORDER BY id ASC"
    );
}

$data = [];
while ($row = mysqli_fetch_assoc($query)) {
    $data[] = $row;
}

echo json_encode($data);
?>