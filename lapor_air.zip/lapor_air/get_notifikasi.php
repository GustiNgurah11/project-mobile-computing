<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: *");
header("Access-Control-Allow-Methods: *");
header("Content-Type: application/json");

include "koneksi.php";

$email = $_GET['email'] ?? '';

if ($email == '') {
    echo json_encode(["success" => false, "message" => "Email wajib diisi"]);
    exit;
}

$query = mysqli_query($conn,
    "SELECT * FROM notifikasi 
    WHERE user_email='$email' 
    ORDER BY created_at DESC"
);

$data = [];
while ($row = mysqli_fetch_assoc($query)) {
    $data[] = $row;
}

echo json_encode($data);
?>