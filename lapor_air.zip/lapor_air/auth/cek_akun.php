<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: *");
header("Access-Control-Allow-Methods: *");
header("Content-Type: application/json");

include '../koneksi.php';

$email = $_POST['email'] ?? '';
$no_telepon = $_POST['no_telepon'] ?? '';

$cek = mysqli_query($conn,
    "SELECT * FROM users WHERE email='$email' AND no_telepon='$no_telepon'"
);

if (mysqli_num_rows($cek) > 0) {
    echo json_encode([
        "success" => true,
        "message" => "Akun ditemukan"
    ]);
} else {
    echo json_encode([
        "success" => false,
        "message" => "Email atau nomor telepon tidak cocok"
    ]);
}
?>