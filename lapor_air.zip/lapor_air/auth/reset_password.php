<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: *");
header("Access-Control-Allow-Methods: *");
header("Content-Type: application/json");

include '../koneksi.php';

$email = $_POST['email'] ?? '';
$no_telepon = $_POST['no_telepon'] ?? '';
$password_baru = $_POST['password_baru'] ?? '';

if ($email == '' || $no_telepon == '' || $password_baru == '') {
    echo json_encode([
        "success" => false,
        "message" => "Semua data wajib diisi"
    ]);
    exit;
}

// Cek apakah email dan nomor telepon cocok
$cek = mysqli_query($conn,
    "SELECT * FROM users WHERE email='$email' AND no_telepon='$no_telepon'"
);

if (mysqli_num_rows($cek) == 0) {
    echo json_encode([
        "success" => false,
        "message" => "Email atau nomor telepon tidak cocok"
    ]);
    exit;
}

// Update password
$update = mysqli_query($conn,
    "UPDATE users SET password='$password_baru' WHERE email='$email'"
);

if ($update) {
    echo json_encode([
        "success" => true,
        "message" => "Password berhasil diubah"
    ]);
} else {
    echo json_encode([
        "success" => false,
        "message" => "Gagal mengubah password"
    ]);
}
?>