<?php

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: *");
header("Access-Control-Allow-Methods: *");
header("Content-Type: application/json");

include '../koneksi.php';

$nama = $_POST['nama'] ?? '';
$email = $_POST['email'] ?? '';
$password = $_POST['password'] ?? '';
$no_telepon = $_POST['no_telepon'] ?? ''; // ← tambah ini

if ($nama == '' || $email == '' || $password == '' || $no_telepon == '') {

    echo json_encode([
        "success" => false,
        "message" => "Semua data wajib diisi"
    ]);

    exit;
}

$cek = mysqli_query(
    $conn,
    "SELECT * FROM users WHERE email='$email'"
);

if (mysqli_num_rows($cek) > 0) {

    echo json_encode([
        "success" => false,
        "message" => "Email sudah terdaftar"
    ]);

    exit;
}

$simpan = mysqli_query(
    $conn,
    "INSERT INTO users(nama, email, password, no_telepon)
    VALUES('$nama','$email','$password','$no_telepon')"
);

if ($simpan) {

    echo json_encode([
        "success" => true,
        "message" => "Registrasi berhasil"
    ]);

} else {

    echo json_encode([
        "success" => false,
        "message" => "Registrasi gagal"
    ]);
}

?>