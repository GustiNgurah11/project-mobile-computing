<?php

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: *");
header("Access-Control-Allow-Methods: *");
header("Content-Type: application/json");

include "koneksi.php";

if($_SERVER['REQUEST_METHOD'] !== 'POST'){
    echo json_encode([
        "success" => false,
        "error" => "Metode request harus POST"
    ]);
    exit;
}

$nama = mysqli_real_escape_string($conn, $_POST['nama'] ?? '');
$alamat = mysqli_real_escape_string($conn, $_POST['alamat'] ?? '');
$keterangan = mysqli_real_escape_string($conn, $_POST['keterangan'] ?? '');
$email = mysqli_real_escape_string($conn, $_POST['email'] ?? ''); // ← tambah ini
$status = "Pending";
$progres = "Laporan Dikirim";
$foto = "";

if(!isset($_FILES['foto']) || $_FILES['foto']['error'] !== UPLOAD_ERR_OK){
    echo json_encode([
        "success" => false,
        "error" => "File foto tidak diterima atau terjadi error upload"
    ]);
    exit;
}

$uploadDir = __DIR__ . '/uploads';
if(!is_dir($uploadDir)){
    mkdir($uploadDir, 0755, true);
}

$namaFile = time() . '_' . str_replace(' ', '_', basename($_FILES['foto']['name']));
$target = $uploadDir . '/' . $namaFile;

$baseUrl = 'http://localhost/lapor_air/uploads/';

if(move_uploaded_file($_FILES['foto']['tmp_name'], $target)){
    $foto = $baseUrl . $namaFile;
} else {
    echo json_encode([
        "success" => false,
        "error" => "Gagal memindahkan file upload"
    ]);
    exit;
}

$query = mysqli_query(
    $conn,
    "INSERT INTO laporann
    (nama, alamat, keterangan, foto, status, progres, email)
    VALUES
    ('$nama', '$alamat', '$keterangan', '$foto', '$status', '$progres', '$email')"
);

if($query){
    echo json_encode([
        "success" => true,
        "message" => "Laporan berhasil ditambahkan",
        "data" => [
            "nama" => $nama,
            "alamat" => $alamat,
            "keterangan" => $keterangan,
            "foto" => $foto,
            "status" => $status,
            "progres" => $progres,
            "email" => $email
        ]
    ]);
}else{
    echo json_encode([
        "success" => false,
        "error" => mysqli_error($conn)
    ]);
}
?>