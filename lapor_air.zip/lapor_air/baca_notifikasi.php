<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: *");
header("Access-Control-Allow-Methods: *");
header("Content-Type: application/json");

include "koneksi.php";

$email = $_POST['email'] ?? '';

mysqli_query($conn,
    "UPDATE notifikasi SET is_read=1 WHERE user_email='$email'"
);

echo json_encode(["success" => true, "message" => "Notifikasi dibaca"]);
?>