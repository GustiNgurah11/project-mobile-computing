<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: *");
header("Access-Control-Allow-Methods: *");
header("Content-Type: application/json");

include "koneksi.php";

$id = $_POST['id'] ?? '';
$status = $_POST['status'] ?? '';
$progres = $_POST['progres'] ?? '';

if ($id == '') {
    echo json_encode(["success" => false, "message" => "ID tidak boleh kosong"]);
    exit;
}

// Ambil data laporan untuk dapat email pelapor
$dataLaporan = mysqli_fetch_assoc(
    mysqli_query($conn, "SELECT * FROM laporann WHERE id='$id'")
);

// Update status laporan
$query = mysqli_query($conn,
    "UPDATE laporann SET status='$status', progres='$progres' WHERE id='$id'"
);

if ($query) {
    // Simpan notifikasi otomatis
    $userEmail = $dataLaporan['email'] ?? '';
    $judul = "Status Laporan Diperbarui";
    $pesan = "Laporan #{$id} anda telah diperbarui menjadi: {$status}. Progress: {$progres}";

    mysqli_query($conn,
        "INSERT INTO notifikasi (user_email, judul, pesan)
        VALUES ('$userEmail', '$judul', '$pesan')"
    );

    echo json_encode(["success" => true, "message" => "Status berhasil diperbarui"]);
} else {
    echo json_encode(["success" => false, "message" => mysqli_error($conn)]);
}
?>