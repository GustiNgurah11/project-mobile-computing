<?php

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: *");
header("Access-Control-Allow-Methods: *");
header("Content-Type: application/json");

include '../koneksi.php';

$email = $_POST['email'] ?? '';
$password = $_POST['password'] ?? '';

if ($email == '' || $password == '') {

    echo json_encode([
        "success" => false,
        "message" => "Email dan Password wajib diisi"
    ]);

    exit;
}

$query = mysqli_query(
    $conn,
    "SELECT * FROM users
    WHERE email='$email'
    AND password='$password'"
);

if (mysqli_num_rows($query) > 0) {

    $data = mysqli_fetch_assoc($query);

    echo json_encode([
        "success" => true,
        "message" => "Login berhasil",
        "userName" => $data['nama'],
        "userEmail" => $data['email']
    ]);

} else {

    echo json_encode([
        "success" => false,
        "message" => "Login gagal"
    ]);
}
?>