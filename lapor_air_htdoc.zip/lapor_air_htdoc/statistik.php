<?php

include "koneksi.php";

$total = mysqli_fetch_assoc(
    mysqli_query(
        $conn,
        "SELECT COUNT(*) AS total FROM laporann"
    )
);

$selesai = mysqli_fetch_assoc(
    mysqli_query(
        $conn,
        "SELECT COUNT(*) AS total
         FROM laporann
         WHERE status='Selesai'"
    )
);

echo json_encode([
    "total_laporan" => $total['total'],
    "laporan_selesai" => $selesai['total']
]);

?>