<?php

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: *");
header("Access-Control-Allow-Methods: *");
header("Content-Type: application/json");

include 'koneksi.php';

if (
    isset($_POST['kategori']) &&
    isset($_POST['lokasi']) &&
    isset($_POST['deskripsi']) &&
    isset($_FILES['foto'])
) {

    $kategori = $_POST['kategori'];
    $lokasi = $_POST['lokasi'];
    $deskripsi = $_POST['deskripsi'];

    $folder = "uploads/";

    if (!file_exists($folder)) {
        mkdir($folder, 0777, true);
    }

    $namaFoto = time() . "_" . $_FILES['foto']['name'];

    $path = $folder . $namaFoto;

    if (move_uploaded_file($_FILES['foto']['tmp_name'], $path)) {

        $query = mysqli_query(
            $conn,
            "INSERT INTO laporann
            (
                kategori,
                lokasi,
                deskripsi,
                foto,
                status,
                progres_laporan
            )
            VALUES
            (
                '$kategori',
                '$lokasi',
                '$deskripsi',
                '$namaFoto',
                'Menunggu',
                'Laporan Terkirim'
            )"
        );

        if ($query) {

            echo json_encode([
                "success" => true,
                "message" => "Laporan berhasil disimpan"
            ]);

        } else {

            echo json_encode([
                "success" => false,
                "message" => mysqli_error($conn)
            ]);
        }

    } else {

        echo json_encode([
            "success" => false,
            "message" => "Upload foto gagal"
        ]);
    }

} else {

    echo json_encode([
        "success" => false,
        "message" => "Data tidak lengkap"
    ]);
}

?>