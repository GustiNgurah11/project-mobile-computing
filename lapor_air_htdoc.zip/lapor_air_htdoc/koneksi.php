<?php

$conn = mysqli_connect(
    "localhost",
    "root",
    "",
    "lapor_air"
);

if(!$conn){
    die("Koneksi gagal");
}

?>